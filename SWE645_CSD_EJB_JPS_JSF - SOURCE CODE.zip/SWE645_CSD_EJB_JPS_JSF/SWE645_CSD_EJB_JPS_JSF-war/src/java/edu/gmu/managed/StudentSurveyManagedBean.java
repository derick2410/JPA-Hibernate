/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.gmu.managed;

import edu.gmu.csd.bean.WinningResult;
import edu.gmu.csd.processor.DataProcessor;
import edu.gmu.entity.Emergencycontactinfo;
import edu.gmu.entity.Studsurveyinfo;
import edu.gmu.session.StudentSurveySessionBean;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import org.apache.commons.lang3.StringUtils;

/**
 *
 *
 * @author Derick Augustine Coutinho
 * @since 17th April 2015
 * @version 1.0
 */
@ManagedBean(name = "studentSurvey")
@SessionScoped
public class StudentSurveyManagedBean {

    @EJB
    private StudentSurveySessionBean studentSurveySessionBean;

    private List<StudentSurveyManagedBean> studentSurveyManagedBeans;
    private WinningResult winningResult;

    private long studentid;
    private String firstname;
    private String lastname;
    private String streetaddress;
    private String zipcode;
    private String city;
    private String sstate;
    private String telnum;
    private String email;
    private String surveydate;
    private String likings;
    private String[] campusLike;
    private String interest;
    private String recomend;
    private String ename1;
    private String etel1;
    private String eemail1;
    private String ename2;
    private String etel2;
    private String eemail2;
    private String raffle;

    public String resetSessionNRedirect(String nextPage) {
        FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("studentSurvey", null);

        return nextPage;
    }

    /**
     *
     * @return
     */
    public String saveStudentSurveyInfo() {
        String fwdToXhtml = null;
        Studsurveyinfo studsurveyinfo = new Studsurveyinfo();

        studsurveyinfo.setFirstname(firstname);
        studsurveyinfo.setLastname(lastname);
        studsurveyinfo.setStreetaddress(streetaddress);
        studsurveyinfo.setZipcode(zipcode);
        studsurveyinfo.setCity(city);
        studsurveyinfo.setSstate(sstate);
        studsurveyinfo.setTelnum(telnum);
        studsurveyinfo.setEmail(email);
        studsurveyinfo.setSurveydate(surveydate);
        studsurveyinfo.setInterest(interest);
        studsurveyinfo.setRecomend(recomend);

        StringBuilder like = new StringBuilder();
        for (String campusLikeVal : campusLike) {
            like.append(campusLikeVal);
            like.append(" ");
        }
        studsurveyinfo.setLikings(like.toString());

        List<Emergencycontactinfo> emergencycontactinfos = new ArrayList<Emergencycontactinfo>();
        Emergencycontactinfo emergencycontactinfo = new Emergencycontactinfo();
        emergencycontactinfo.setEcontactname(ename1);
        emergencycontactinfo.setEcontactphone(etel1);
        emergencycontactinfo.setEcontactmail(eemail1);
        emergencycontactinfos.add(emergencycontactinfo);

        if (StringUtils.isNotEmpty(ename2)) {
            emergencycontactinfo = new Emergencycontactinfo();
            emergencycontactinfo.setEcontactname(ename2);
            emergencycontactinfo.setEcontactphone(etel2);
            emergencycontactinfo.setEcontactmail(eemail2);
            emergencycontactinfos.add(emergencycontactinfo);
        }

        studsurveyinfo.setEmergencycontactinfoList(emergencycontactinfos);
        boolean isSaveSuccess = studentSurveySessionBean.saveStudentSurveyInfo(studsurveyinfo);

        if (isSaveSuccess) {
            WinningResult result = DataProcessor.calculateMeanStandardDeviation(raffle);
            setWinningResult(result);

            if (null != result && result.getMean() > 90) {
                // WinnerAcknowledgement JSP
                fwdToXhtml = "winnerAcknowledgement";
            } else {
                // SimpleAcknowledgement JSP
                fwdToXhtml = "simpleAcknowledgement";
            }
        } else {
            fwdToXhtml = "errorPage";
        }

        return fwdToXhtml;
    }

    public List<StudentSurveyManagedBean> retireveStudentSurveyInfo() {
        List<Studsurveyinfo> studsurveyinfos = studentSurveySessionBean.retrieveStudentSurveyInfo();

        return setStudentSurveyDetails(studsurveyinfos);
    }

    public String searchStudentSurveyInfo() {
        Studsurveyinfo studsurveyinfo = new Studsurveyinfo();
        boolean doSearch = false;

        if (!StringUtils.EMPTY.equalsIgnoreCase(firstname)) {
            studsurveyinfo.setFirstname(firstname + "%");
            doSearch = true;
        }
        if (!StringUtils.EMPTY.equalsIgnoreCase(lastname)) {
            studsurveyinfo.setLastname(lastname + "%");
            doSearch = true;
        }
        if (!StringUtils.EMPTY.equalsIgnoreCase(sstate)) {
            studsurveyinfo.setSstate(sstate + "%");
            doSearch = true;
        }
        if (!StringUtils.EMPTY.equalsIgnoreCase(city)) {
            studsurveyinfo.setCity(city + "%");
            doSearch = true;
        }

        if (doSearch) {
            List<Studsurveyinfo> studsurveyinfos = studentSurveySessionBean.searchStudentSurveyInfo(studsurveyinfo);
            setStudentSurveyManagedBeans(setStudentSurveyDetails(studsurveyinfos));
        }

        return "searchStudentSurvey";
    }

    public String deleteStudentSurveyInfo(long studentId, String isSearch) {
        String fwdToXhtml = null;
        if (!studentSurveySessionBean.deleteStudentSurveyInfo(studentId)) {
            fwdToXhtml = "errorPage";
        } else {
            if (StringUtils.equalsIgnoreCase("YES", isSearch)) {
                searchStudentSurveyInfo();
            } else {
                retireveStudentSurveyInfo();
            }
        }

        return fwdToXhtml;
    }

    public List<StudentSurveyManagedBean> setStudentSurveyDetails(List<Studsurveyinfo> studsurveyinfos) {
        List<StudentSurveyManagedBean> studSurMangBeanList = new ArrayList<StudentSurveyManagedBean>();
        StudentSurveyManagedBean managedBean = null;

        if (null != studsurveyinfos) {
            for (Studsurveyinfo studsurveyinfo : studsurveyinfos) {
                managedBean = new StudentSurveyManagedBean();

                managedBean.setStudentid(studsurveyinfo.getStudentid());
                managedBean.setFirstname(studsurveyinfo.getFirstname());
                managedBean.setLastname(studsurveyinfo.getLastname());
                managedBean.setStreetaddress(studsurveyinfo.getStreetaddress());
                managedBean.setZipcode(studsurveyinfo.getZipcode());
                managedBean.setCity(studsurveyinfo.getCity());
                managedBean.setSstate(studsurveyinfo.getSstate());
                managedBean.setTelnum(studsurveyinfo.getTelnum());
                managedBean.setEmail(studsurveyinfo.getEmail());
                managedBean.setTelnum(studsurveyinfo.getTelnum());
                managedBean.setLikings(studsurveyinfo.getLikings());
                managedBean.setInterest(studsurveyinfo.getInterest());
                managedBean.setRecomend(studsurveyinfo.getRecomend());

                if (null != studsurveyinfo.getEmergencycontactinfoList()) {
                    int count = 0;
                    for (Emergencycontactinfo emergencycontactinfo : studsurveyinfo.getEmergencycontactinfoList()) {
                        if (count == 0) {
                            managedBean.setEname1(emergencycontactinfo.getEcontactname());
                            managedBean.setEtel1(emergencycontactinfo.getEcontactphone());
                            managedBean.setEemail1(emergencycontactinfo.getEcontactmail());
                        } else {
                            managedBean.setEname2(emergencycontactinfo.getEcontactname());
                            managedBean.setEtel2(emergencycontactinfo.getEcontactphone());
                            managedBean.setEemail2(emergencycontactinfo.getEcontactmail());
                        }
                        count = 1;
                    }
                }

                studSurMangBeanList.add(managedBean);
            }
        }

        return studSurMangBeanList;
    }

    public void setStudentSurveyManagedBeans(List<StudentSurveyManagedBean> studentSurveyManagedBeans) {
        this.studentSurveyManagedBeans = studentSurveyManagedBeans;
    }

    public List<StudentSurveyManagedBean> getStudentSurveyManagedBeans() {
        return studentSurveyManagedBeans;
    }

    public WinningResult getWinningResult() {
        return winningResult;
    }

    public long getStudentid() {
        return studentid;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getStreetaddress() {
        return streetaddress;
    }

    public String getZipcode() {
        return zipcode;
    }

    public String getCity() {
        return city;
    }

    public String getSstate() {
        return sstate;
    }

    public String getTelnum() {
        return telnum;
    }

    public String getEmail() {
        return email;
    }

    public String getSurveydate() {
        return surveydate;
    }

    public String getLikings() {
        return likings;
    }

    public String[] getCampusLike() {
        return campusLike;
    }

    public String getInterest() {
        return interest;
    }

    public String getRecomend() {
        return recomend;
    }

    public void setWinningResult(WinningResult winningResult) {
        this.winningResult = winningResult;
    }

    public void setStudentid(long studentid) {
        this.studentid = studentid;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setStreetaddress(String streetaddress) {
        this.streetaddress = streetaddress;
    }

    public void setZipcode(String zipcode) {
        if (null != zipcode) {
            if (zipcode.length() == 5) {
                for (Map.Entry<String, String> entry : getZipCityStateMap().entrySet()) {
                    if (entry.getKey().equals(zipcode)) {
                        String[] cityState = entry.getValue().split("-");
                        city = cityState[0];
                        sstate = cityState[1];
                        break;
                    } else {
                        city = "";
                        sstate = "";
                    }
                }
            }
        }
        this.zipcode = zipcode;
    }

    public Map<String, String> getZipCityStateMap() {
        Map<String, String> zipCityState = new HashMap<String, String>();
        zipCityState.put("22312", "Alexandria-VA");
        zipCityState.put("22030", "Fairfax-VA");
        zipCityState.put("22301", "Tysons Corner-MD");
        zipCityState.put("20148", "Ashburn-VA");

        return zipCityState;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setSstate(String sstate) {
        this.sstate = sstate;
    }

    public void setTelnum(String telnum) {
        this.telnum = telnum;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setSurveydate(String surveydate) {
        this.surveydate = surveydate;
    }

    public void setLikings(String likings) {
        this.likings = likings;
    }

    public void setCampusLike(String[] campusLike) {
        this.campusLike = campusLike;
    }

    public void setInterest(String interest) {
        this.interest = interest;
    }

    public void setRecomend(String recomend) {
        this.recomend = recomend;
    }

    public void setEname1(String ename1) {
        this.ename1 = ename1;
    }

    public void setEtel1(String etel1) {
        this.etel1 = etel1;
    }

    public void setEemail1(String eemail1) {
        this.eemail1 = eemail1;
    }

    public void setEname2(String ename2) {
        this.ename2 = ename2;
    }

    public void setEtel2(String etel2) {
        this.etel2 = etel2;
    }

    public void setEemail2(String eemail2) {
        this.eemail2 = eemail2;
    }

    public String getEname1() {
        return ename1;
    }

    public String getEtel1() {
        return etel1;
    }

    public String getEemail1() {
        return eemail1;
    }

    public String getEname2() {
        return ename2;
    }

    public String getEtel2() {
        return etel2;
    }

    public String getEemail2() {
        return eemail2;
    }

    public String getRaffle() {
        return raffle;
    }

    public void setRaffle(String raffle) {
        this.raffle = raffle;
    }
}
