/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.gmu.session;

import edu.gmu.entity.Studsurveyinfo;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.sql.DataSourceDefinition;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * @author Derick Coutinho
 */
@Stateless
@LocalBean
public class StudentSurveySessionBean {

    @PersistenceContext(unitName = "SWE645_CSD_EJB_JPS_JSF-ejbPU")
    private EntityManager entityManager;

    /**
     *
     * @param studsurveyinfo
     * @return
     */
    public boolean saveStudentSurveyInfo(Studsurveyinfo studsurveyinfo) {
        try {
            persist(studsurveyinfo);
        } catch (Exception excp) {
            excp.printStackTrace();
            return false;
        }
        return true;
    }

    public List<Studsurveyinfo> retrieveStudentSurveyInfo() {
        TypedQuery<Studsurveyinfo> studentListQuery = entityManager.createNamedQuery("Studsurveyinfo.findAll", Studsurveyinfo.class);
        return studentListQuery.getResultList();
    }

    public List<Studsurveyinfo> searchStudentSurveyInfo(Studsurveyinfo studsurveyinfo) {
        Query query = entityManager.createQuery("SELECT s from Studsurveyinfo s WHERE s.firstname LIKE :first_name OR s.lastname LIKE :last_name OR s.sstate LIKE :state OR s.city LIKE :city ORDER BY s.lastname ASC");

        String firstName = studsurveyinfo.getFirstname();
        String lastName = studsurveyinfo.getLastname();
        String city = studsurveyinfo.getCity();
        String state = studsurveyinfo.getSstate();

        query.setParameter("first_name", firstName);
        query.setParameter("last_name", lastName);
        query.setParameter("city", city);
        query.setParameter("state", state);
        
        return query.getResultList();
    }

    public boolean deleteStudentSurveyInfo(long studentId) {
        try {
            Studsurveyinfo studsurveyinfo = entityManager.find(Studsurveyinfo.class, studentId);
            entityManager.remove(studsurveyinfo);
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }

    public void persist(Object object) {
        entityManager.persist(object);
    }
}
