/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.gmu.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author DELL
 */
@Entity
@Table(name = "EMERGENCYCONTACTINFO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Emergencycontactinfo.findAll", query = "SELECT e FROM Emergencycontactinfo e"),
    @NamedQuery(name = "Emergencycontactinfo.findByEcontactid", query = "SELECT e FROM Emergencycontactinfo e WHERE e.econtactid = :econtactid"),
    @NamedQuery(name = "Emergencycontactinfo.findByEcontactname", query = "SELECT e FROM Emergencycontactinfo e WHERE e.econtactname = :econtactname"),
    @NamedQuery(name = "Emergencycontactinfo.findByEcontactphone", query = "SELECT e FROM Emergencycontactinfo e WHERE e.econtactphone = :econtactphone"),
    @NamedQuery(name = "Emergencycontactinfo.findByEcontactmail", query = "SELECT e FROM Emergencycontactinfo e WHERE e.econtactmail = :econtactmail")})
public class Emergencycontactinfo implements Serializable {

    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @NotNull
    @SequenceGenerator(name = "ECONTACTID_GENERATOR", sequenceName = "seq_emergency_contact_id", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ECONTACTID_GENERATOR")
    @Column(name = "ECONTACTID")
    private long econtactid;

    @Size(max = 50)
    @Column(name = "ECONTACTNAME")
    private String econtactname;

    @Size(max = 15)
    @Column(name = "ECONTACTPHONE")
    private String econtactphone;

    @Size(max = 50)
    @Column(name = "ECONTACTMAIL")
    private String econtactmail;

    public Emergencycontactinfo() {
    }

    public Emergencycontactinfo(long econtactid) {
        this.econtactid = econtactid;
    }

    public long getEcontactid() {
        return econtactid;
    }

    public void setEcontactid(long econtactid) {
        this.econtactid = econtactid;
    }

    public String getEcontactname() {
        return econtactname;
    }

    public void setEcontactname(String econtactname) {
        this.econtactname = econtactname;
    }

    public String getEcontactphone() {
        return econtactphone;
    }

    public void setEcontactphone(String econtactphone) {
        this.econtactphone = econtactphone;
    }

    public String getEcontactmail() {
        return econtactmail;
    }

    public void setEcontactmail(String econtactmail) {
        this.econtactmail = econtactmail;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Emergencycontactinfo)) {
            return false;
        }

        return true;
    }

    @Override
    public String toString() {
        return "edu.gmu.entity.Emergencycontactinfo[ econtactid=" + econtactid + " ]";
    }

}
