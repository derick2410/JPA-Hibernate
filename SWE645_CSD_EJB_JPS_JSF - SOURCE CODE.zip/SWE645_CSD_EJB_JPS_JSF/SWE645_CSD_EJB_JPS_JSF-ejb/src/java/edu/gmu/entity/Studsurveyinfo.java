/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.gmu.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author DELL
 */
@Entity
@Table(name = "STUDSURVEYINFO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Studsurveyinfo.findAll", query = "SELECT s FROM Studsurveyinfo s"),
    @NamedQuery(name = "Studsurveyinfo.findByStudentid", query = "SELECT s FROM Studsurveyinfo s WHERE s.studentid = :studentid"),
    @NamedQuery(name = "Studsurveyinfo.findByFirstname", query = "SELECT s FROM Studsurveyinfo s WHERE s.firstname = :firstname"),
    @NamedQuery(name = "Studsurveyinfo.findByLastname", query = "SELECT s FROM Studsurveyinfo s WHERE s.lastname = :lastname"),
    @NamedQuery(name = "Studsurveyinfo.findByStreetaddress", query = "SELECT s FROM Studsurveyinfo s WHERE s.streetaddress = :streetaddress"),
    @NamedQuery(name = "Studsurveyinfo.findByZipcode", query = "SELECT s FROM Studsurveyinfo s WHERE s.zipcode = :zipcode"),
    @NamedQuery(name = "Studsurveyinfo.findByCity", query = "SELECT s FROM Studsurveyinfo s WHERE s.city = :city"),
    @NamedQuery(name = "Studsurveyinfo.findBySstate", query = "SELECT s FROM Studsurveyinfo s WHERE s.sstate = :sstate"),
    @NamedQuery(name = "Studsurveyinfo.findByTelnum", query = "SELECT s FROM Studsurveyinfo s WHERE s.telnum = :telnum"),
    @NamedQuery(name = "Studsurveyinfo.findByEmail", query = "SELECT s FROM Studsurveyinfo s WHERE s.email = :email"),
    @NamedQuery(name = "Studsurveyinfo.findBySurveydate", query = "SELECT s FROM Studsurveyinfo s WHERE s.surveydate = :surveydate"),
    @NamedQuery(name = "Studsurveyinfo.findByLikings", query = "SELECT s FROM Studsurveyinfo s WHERE s.likings = :likings"),
    @NamedQuery(name = "Studsurveyinfo.findByInterest", query = "SELECT s FROM Studsurveyinfo s WHERE s.interest = :interest"),
    @NamedQuery(name = "Studsurveyinfo.findByRecomend", query = "SELECT s FROM Studsurveyinfo s WHERE s.recomend = :recomend")})
public class Studsurveyinfo implements Serializable {

    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @NotNull
    @SequenceGenerator(name = "STUDENTID_GENERATOR", sequenceName = "seq_student_id", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "STUDENTID_GENERATOR")
    @Column(name = "STUDENTID")
    private long studentid;

    @Size(max = 50)
    @Column(name = "FIRSTNAME")
    private String firstname;

    @Size(max = 50)
    @Column(name = "LASTNAME")
    private String lastname;

    @Size(max = 100)
    @Column(name = "STREETADDRESS")
    private String streetaddress;

    @Size(max = 5)
    @Column(name = "ZIPCODE")
    private String zipcode;

    @Size(max = 30)
    @Column(name = "CITY")
    private String city;

    @Size(max = 30)
    @Column(name = "SSTATE")
    private String sstate;

    @Size(max = 20)
    @Column(name = "TELNUM")
    private String telnum;

    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Size(max = 50)
    @Column(name = "EMAIL")
    private String email;

    @Size(max = 50)
    @Column(name = "SURVEYDATE")
    private String surveydate;

    @Size(max = 50)
    @Column(name = "LIKINGS")
    private String likings;

    @Size(max = 20)
    @Column(name = "INTEREST")
    private String interest;

    @Size(max = 20)
    @Column(name = "RECOMEND")
    private String recomend;

    @OneToMany(cascade = {CascadeType.ALL}, fetch = FetchType.EAGER)
    @JoinTable(name = "stud_emergencycontct_details", joinColumns = {
        @JoinColumn(name = "studentid")}, inverseJoinColumns = {
        @JoinColumn(name = "econtactid")})
    private List<Emergencycontactinfo> emergencycontactinfoList;

    public Studsurveyinfo() {
    }

    public Studsurveyinfo(long studentid) {
        this.studentid = studentid;
    }

    public long getStudentid() {
        return studentid;
    }

    public void setStudentid(long studentid) {
        this.studentid = studentid;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getStreetaddress() {
        return streetaddress;
    }

    public void setStreetaddress(String streetaddress) {
        this.streetaddress = streetaddress;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getSstate() {
        return sstate;
    }

    public void setSstate(String sstate) {
        this.sstate = sstate;
    }

    public String getTelnum() {
        return telnum;
    }

    public void setTelnum(String telnum) {
        this.telnum = telnum;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSurveydate() {
        return surveydate;
    }

    public void setSurveydate(String surveydate) {
        this.surveydate = surveydate;
    }

    public String getLikings() {
        return likings;
    }

    public void setLikings(String likings) {
        this.likings = likings;
    }

    public String getInterest() {
        return interest;
    }

    public void setInterest(String interest) {
        this.interest = interest;
    }

    public String getRecomend() {
        return recomend;
    }

    public void setRecomend(String recomend) {
        this.recomend = recomend;
    }

    @XmlTransient
    public List<Emergencycontactinfo> getEmergencycontactinfoList() {
        return emergencycontactinfoList;
    }

    public void setEmergencycontactinfoList(List<Emergencycontactinfo> emergencycontactinfoList) {
        this.emergencycontactinfoList = emergencycontactinfoList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Studsurveyinfo)) {
            return false;
        }

        return true;
    }

    @Override
    public String toString() {
        return "edu.gmu.entity.Studsurveyinfo[ studentid=" + studentid + " ]";
    }
}
